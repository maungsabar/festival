<?php $__env->startSection('title', $sponsor ? 'Edit Sponsor' : 'Tambah Sponsor'); ?>

<?php $__env->startSection('admin_content'); ?>
<div class="max-w-2xl mx-auto">
  <div class="mb-6">
    <a href="<?php echo e(route('admin.sponsor.index')); ?>"
       class="inline-flex items-center gap-1.5 text-sm text-gray-400 hover:text-blue-600 transition-colors mb-4">
      <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/>
      </svg>Kembali
    </a>
    <h1 class="text-xl sm:text-2xl font-black text-gray-900"><?php echo e($sponsor ? 'Edit Sponsor' : 'Tambah Sponsor'); ?></h1>
  </div>

  <?php if($errors->any()): ?>
  <div class="flex items-start gap-3 bg-red-50 border border-red-200 rounded-2xl p-4 mb-5">
    <svg class="w-5 h-5 text-red-500 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>
    </svg>
    <ul class="space-y-1"><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li class="text-sm text-red-700"><?php echo e($e); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul>
  </div>
  <?php endif; ?>

  <form method="POST" action="<?php echo e($sponsor ? route('admin.sponsor.update', $sponsor) : route('admin.sponsor.store')); ?>" enctype="multipart/form-data">
    <?php echo csrf_field(); ?> <?php if($sponsor): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>

    <div class="bg-white border border-gray-100 rounded-2xl shadow-sm p-5 mb-4 space-y-4">
      
      <div>
        <label class="block text-sm font-semibold text-gray-700 mb-1.5">Nama Sponsor <span class="text-red-500">*</span></label>
        <input type="text" name="nama" value="<?php echo e(old('nama', $sponsor?->nama)); ?>"
               class="w-full border <?php echo e($errors->has('nama')?'border-red-400 bg-red-50':'border-gray-200 focus:border-blue-500'); ?>

                      rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20 transition-all"
               placeholder="Contoh: PT Bank Mandiri, Telkomsel" required>
      </div>

      
      <div>
        <label class="block text-sm font-semibold text-gray-700 mb-1.5">Link Website <span class="text-gray-400 font-normal text-xs">(opsional)</span></label>
        <input type="url" name="link" value="<?php echo e(old('link', $sponsor?->link)); ?>"
               class="w-full border <?php echo e($errors->has('link')?'border-red-400 bg-red-50':'border-gray-200 focus:border-blue-500'); ?>

                      rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20 transition-all"
               placeholder="https://example.com">
      </div>

      
      <div>
        <label class="block text-sm font-semibold text-gray-700 mb-1.5">Logo Sponsor <span class="text-red-500"><?php echo e($sponsor ? '' : '*'); ?></span> <span class="text-gray-400 text-xs font-normal">(PNG/JPG/SVG/WebP, maks 2MB)</span></label>
        <input type="file" name="logo" accept="image/*" <?php echo e($sponsor ? '' : 'required'); ?>

               class="w-full border border-gray-200 focus:border-blue-500 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20 transition-all">
        <?php if($sponsor && $sponsor->logo): ?>
          <div class="mt-3 flex items-center gap-3">
            <div class="w-16 h-12 border border-gray-200 bg-gray-50 rounded-lg flex items-center justify-center overflow-hidden">
              <img src="<?php echo e(asset('storage/sponsors/' . $sponsor->logo)); ?>" class="w-full h-full object-contain p-1">
            </div>
            <div class="text-xs text-gray-500">
              <p class="font-semibold text-gray-700">Logo saat ini</p>
              <p class="truncate max-w-xs text-gray-400"><?php echo e($sponsor->logo); ?></p>
            </div>
          </div>
        <?php endif; ?>
      </div>

      
      <div>
        <label class="flex items-center gap-3 cursor-pointer select-none p-4 bg-gray-50 hover:bg-gray-100 rounded-xl transition-colors w-full">
          <div class="relative shrink-0">
            <input type="checkbox" name="aktif" value="1" id="aktifToggle"
                   <?php echo e(old('aktif', $sponsor ? ($sponsor->aktif ? '1' : '') : '1') ? 'checked' : ''); ?> class="sr-only peer">
            <div class="w-11 h-6 bg-gray-300 peer-checked:bg-blue-600 rounded-full transition-colors"></div>
            <div class="absolute top-0.5 left-0.5 w-5 h-5 bg-white rounded-full shadow transition-transform peer-checked:translate-x-5"></div>
          </div>
          <div>
            <p class="font-semibold text-gray-700 text-sm">Status Sponsor Aktif</p>
            <p class="text-xs text-gray-400">Tampil di halaman beranda publik</p>
          </div>
        </label>
      </div>
    </div>

    <div class="flex gap-3">
      <button type="submit"
              class="flex-1 bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 rounded-xl text-sm transition-all active:scale-95">
        <?php echo e($sponsor ? 'Simpan Perubahan' : 'Tambah Sponsor'); ?>

      </button>
      <a href="<?php echo e(route('admin.sponsor.index')); ?>"
         class="inline-flex items-center justify-center bg-gray-100 hover:bg-gray-200
                text-gray-700 font-semibold px-5 py-3 rounded-xl text-sm transition-all active:scale-95">Batal</a>
    </div>
  </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\milbos\resources\views/admin/sponsor/form.blade.php ENDPATH**/ ?>