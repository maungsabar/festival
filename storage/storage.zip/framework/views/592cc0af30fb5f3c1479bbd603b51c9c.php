<?php $__env->startSection('title', 'Kelola Sponsor'); ?>
<?php $__env->startSection('admin_content'); ?>

<div class="flex flex-wrap items-center justify-between gap-3 mb-6">
  <div>
    <h1 class="text-xl sm:text-2xl font-black text-gray-900">Kelola Sponsor</h1>
    <p class="text-gray-400 text-sm mt-0.5"><?php echo e($sponsors->count()); ?> sponsor terdaftar</p>
  </div>
  <a href="<?php echo e(route('admin.sponsor.create')); ?>"
     class="inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white
            font-semibold text-sm px-4 py-2.5 rounded-xl shadow-sm transition-all active:scale-95">
    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/>
    </svg>Tambah Sponsor
  </a>
</div>

<?php if(session('success')): ?>
<div class="flex items-center gap-3 bg-emerald-50 border border-emerald-200 rounded-2xl p-4 mb-5 text-sm text-emerald-800">
  <svg class="w-5 h-5 text-emerald-500 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
  </svg>
  <?php echo e(session('success')); ?>

</div>
<?php endif; ?>


<div class="space-y-3 sm:hidden">
  <?php $__empty_1 = true; $__currentLoopData = $sponsors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
  <div class="bg-white border border-gray-100 rounded-2xl p-4 shadow-sm <?php echo e(!$s->aktif?'opacity-60':''); ?>">
    <div class="flex items-center gap-3 mb-3">
      <div class="w-12 h-12 rounded-xl border border-gray-100 flex items-center justify-center bg-gray-50 overflow-hidden shrink-0">
        <img src="<?php echo e(asset('storage/sponsors/' . $s->logo)); ?>" class="w-full h-full object-contain p-1" alt="<?php echo e($s->nama); ?>">
      </div>
      <div class="flex-1 min-w-0">
        <p class="font-bold text-gray-900 text-sm truncate"><?php echo e($s->nama); ?></p>
        <p class="text-xs text-gray-400 truncate"><?php echo e($s->link ?? '-'); ?></p>
      </div>
      <div class="flex items-center gap-1 shrink-0">
        <span class="w-1.5 h-1.5 rounded-full <?php echo e($s->aktif?'bg-emerald-500':'bg-gray-300'); ?>"></span>
        <span class="text-xs <?php echo e($s->aktif?'text-emerald-600':'text-gray-400'); ?>"><?php echo e($s->aktif?'Aktif':'Nonaktif'); ?></span>
      </div>
    </div>
    <div class="flex items-center gap-2">
      <a href="<?php echo e(route('admin.sponsor.edit', $s)); ?>"
         class="flex-1 text-center text-xs bg-blue-50 hover:bg-blue-100 text-blue-700 py-2 rounded-lg font-medium transition-all">Edit</a>
      <form method="POST" action="<?php echo e(route('admin.sponsor.destroy', $s)); ?>" class="flex-1"
            onsubmit="return confirm('Hapus sponsor <?php echo e(addslashes($s->nama)); ?>?')">
        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
        <button class="w-full text-xs bg-red-50 hover:bg-red-100 text-red-600 py-2 rounded-lg transition-all">Hapus</button>
      </form>
    </div>
  </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
  <div class="bg-white border border-gray-100 rounded-2xl p-12 text-center shadow-sm text-gray-400 text-sm">Belum ada sponsor.</div>
  <?php endif; ?>
</div>


<div class="hidden sm:block bg-white border border-gray-100 rounded-2xl shadow-sm overflow-hidden">
  <div class="overflow-x-auto">
    <table class="w-full">
      <thead>
        <tr class="bg-gray-50 border-b border-gray-100">
          <th class="text-left px-5 py-3.5 text-xs font-semibold text-gray-500 uppercase tracking-wider w-24">Logo</th>
          <th class="text-left px-4 py-3.5 text-xs font-semibold text-gray-500 uppercase tracking-wider">Nama Sponsor</th>
          <th class="text-left px-4 py-3.5 text-xs font-semibold text-gray-500 uppercase tracking-wider">Website Link</th>
          <th class="text-left px-4 py-3.5 text-xs font-semibold text-gray-500 uppercase tracking-wider w-36">Status</th>
          <th class="text-left px-4 py-3.5 text-xs font-semibold text-gray-500 uppercase tracking-wider w-36">Aksi</th>
        </tr>
      </thead>
      <tbody class="divide-y divide-gray-50">
        <?php $__empty_1 = true; $__currentLoopData = $sponsors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr class="hover:bg-gray-50/70 transition-colors <?php echo e(!$s->aktif?'opacity-60':''); ?>">
          <td class="px-5 py-3">
            <div class="w-14 h-10 rounded-lg border border-gray-100 flex items-center justify-center bg-gray-50 overflow-hidden">
              <img src="<?php echo e(asset('storage/sponsors/' . $s->logo)); ?>" class="w-full h-full object-contain p-1" alt="<?php echo e($s->nama); ?>">
            </div>
          </td>
          <td class="px-4 py-3">
            <p class="font-semibold text-sm text-gray-900"><?php echo e($s->nama); ?></p>
          </td>
          <td class="px-4 py-3">
            <?php if($s->link): ?>
              <a href="<?php echo e($s->link); ?>" target="_blank" class="text-xs text-blue-600 hover:underline flex items-center gap-1">
                <?php echo e($s->link); ?>

                <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"/>
                </svg>
              </a>
            <?php else: ?>
              <span class="text-xs text-gray-300">—</span>
            <?php endif; ?>
          </td>
          <td class="px-4 py-3">
            <div class="flex items-center gap-1.5">
              <span class="w-1.5 h-1.5 rounded-full <?php echo e($s->aktif?'bg-emerald-500':'bg-gray-300'); ?>"></span>
              <span class="text-xs text-gray-600"><?php echo e($s->aktif?'Aktif':'Nonaktif'); ?></span>
            </div>
          </td>
          <td class="px-4 py-3">
            <div class="flex items-center gap-1.5">
              <a href="<?php echo e(route('admin.sponsor.edit', $s)); ?>"
                 class="text-xs bg-blue-50 hover:bg-blue-100 text-blue-700 px-2.5 py-1.5 rounded-lg transition-all font-medium">Edit</a>
              <form method="POST" action="<?php echo e(route('admin.sponsor.destroy', $s)); ?>"
                    onsubmit="return confirm('Hapus sponsor <?php echo e(addslashes($s->nama)); ?>?')">
                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                <button class="text-xs bg-red-50 hover:bg-red-100 text-red-600 px-2.5 py-1.5 rounded-lg transition-all">Hapus</button>
              </form>
            </div>
          </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
          <td colspan="5" class="px-5 py-12 text-center text-sm text-gray-400">Belum ada sponsor.</td>
        </tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\milbos\resources\views/admin/sponsor/index.blade.php ENDPATH**/ ?>