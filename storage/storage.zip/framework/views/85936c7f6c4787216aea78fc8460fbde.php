
<?php $__env->startSection('title', 'Detail — ' . $pendaftar->nama); ?>
<?php $__env->startSection('admin_content'); ?>

<div class="mb-6">
  <a href="<?php echo e(route('admin.pendaftar.index')); ?>"
     class="inline-flex items-center gap-1.5 text-sm text-gray-400 hover:text-blue-600 transition-colors mb-4">
    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/>
    </svg>Kembali ke Daftar
  </a>
  <h1 class="text-xl sm:text-2xl font-black text-gray-900">Detail Pendaftar</h1>
</div>

<div class="grid grid-cols-1 lg:grid-cols-3 gap-5">

  
  <div class="lg:col-span-2 space-y-5">

    
    <div class="bg-white border border-gray-100 rounded-2xl shadow-sm overflow-hidden">
      <div class="h-16 bg-gradient-to-r <?php echo e($pendaftar->gender==='Putra'?'from-blue-500 to-blue-700':'from-pink-500 to-pink-700'); ?>"></div>
      <div class="px-5 pb-5">
        <div class="flex items-end gap-3 -mt-7 mb-4">
          <div class="w-14 h-14 rounded-2xl border-4 border-white shadow flex items-center justify-center text-2xl font-black
                      <?php echo e($pendaftar->gender==='Putra'?'bg-blue-100 text-blue-700':'bg-pink-100 text-pink-700'); ?>">
            <?php echo e(strtoupper(substr($pendaftar->nama,0,1))); ?>

          </div>
          <div class="pb-1 flex-1 min-w-0">
            <h2 class="font-bold text-gray-900 text-base truncate"><?php echo e($pendaftar->nama); ?></h2>
            <p class="text-sm text-gray-500 font-mono"><?php echo e($pendaftar->nisn); ?></p>
          </div>
          <div class="pb-1">
            <?php if($pendaftar->status_verifikasi==='Terverifikasi'): ?>
              <span class="inline-flex items-center gap-1.5 text-xs font-semibold bg-emerald-100 text-emerald-700 px-2.5 py-1 rounded-full">
                <span class="w-1.5 h-1.5 bg-emerald-500 rounded-full"></span>Terverifikasi
              </span>
            <?php elseif($pendaftar->status_verifikasi==='Ditolak'): ?>
              <span class="inline-flex items-center gap-1.5 text-xs font-semibold bg-red-100 text-red-700 px-2.5 py-1 rounded-full">
                <span class="w-1.5 h-1.5 bg-red-500 rounded-full"></span>Ditolak
              </span>
            <?php else: ?>
              <span class="inline-flex items-center gap-1.5 text-xs font-semibold bg-amber-100 text-amber-700 px-2.5 py-1 rounded-full">
                <span class="w-1.5 h-1.5 bg-amber-500 rounded-full animate-pulse"></span>Belum
              </span>
            <?php endif; ?>
          </div>
        </div>

        <div class="grid grid-cols-2 sm:grid-cols-3 gap-3">
          <div class="bg-gray-50 rounded-xl p-3">
            <p class="text-[10px] text-gray-400 font-semibold uppercase tracking-wider mb-1">Gender</p>
            <span class="text-sm font-semibold <?php echo e($pendaftar->gender==='Putra'?'text-blue-700':'text-pink-700'); ?>">
              <?php echo e($pendaftar->gender==='Putra'?'♂':'♀'); ?> <?php echo e($pendaftar->gender); ?>

            </span>
          </div>
          <div class="bg-gray-50 rounded-xl p-3">
            <p class="text-[10px] text-gray-400 font-semibold uppercase tracking-wider mb-1">Lomba</p>
            <p class="text-sm font-semibold text-gray-900 truncate"><?php echo e($pendaftar->lomba?->nama_lomba??'-'); ?></p>
            <?php if($pendaftar->lomba): ?>
            <span class="text-[10px] <?php echo e($pendaftar->lomba->tipe==='team'?'text-violet-600':'text-gray-500'); ?>">
              <?php echo e($pendaftar->lomba->tipe==='team'?'👥 Beregu':'👤 Perorangan'); ?>

            </span>
            <?php endif; ?>
          </div>
          <?php if($pendaftar->nama_tim): ?>
          <div class="bg-violet-50 rounded-xl p-3">
            <p class="text-[10px] text-violet-400 font-semibold uppercase tracking-wider mb-1">Nama Tim</p>
            <p class="text-sm font-bold text-violet-800"><?php echo e($pendaftar->nama_tim); ?></p>
          </div>
          <?php endif; ?>
          <div class="bg-gray-50 rounded-xl p-3 col-span-2 sm:col-span-3">
            <p class="text-[10px] text-gray-400 font-semibold uppercase tracking-wider mb-1">Sekolah</p>
            <p class="text-sm font-semibold text-gray-900"><?php echo e($pendaftar->nama_sekolah); ?></p>
            <p class="text-xs text-gray-500 mt-0.5"><?php echo e($pendaftar->alamat_sekolah); ?></p>
          </div>
          <div class="bg-gray-50 rounded-xl p-3">
            <p class="text-[10px] text-gray-400 font-semibold uppercase tracking-wider mb-1">HP Peserta</p>
            <a href="tel:<?php echo e($pendaftar->hp_peserta); ?>" class="text-sm font-semibold text-blue-600 hover:underline"><?php echo e($pendaftar->hp_peserta??'-'); ?></a>
          </div>
          <div class="bg-gray-50 rounded-xl p-3">
            <p class="text-[10px] text-gray-400 font-semibold uppercase tracking-wider mb-1">Pendamping</p>
            <p class="text-sm font-semibold text-gray-900"><?php echo e($pendaftar->nama_pendamping??'-'); ?></p>
            <?php if($pendaftar->hp_pendamping): ?>
            <a href="tel:<?php echo e($pendaftar->hp_pendamping); ?>" class="text-xs text-blue-600 hover:underline"><?php echo e($pendaftar->hp_pendamping); ?></a>
            <?php endif; ?>
          </div>
          <?php if($pendaftar->link_twibbon): ?>
          <div class="bg-pink-50 rounded-xl p-3">
            <p class="text-[10px] text-pink-400 font-semibold uppercase tracking-wider mb-1">Twibbon</p>
            <a href="<?php echo e($pendaftar->link_twibbon); ?>" target="_blank"
               class="text-xs text-pink-600 hover:text-pink-800 font-semibold flex items-center gap-1">
              Lihat Link
              <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"/>
              </svg>
            </a>
          </div>
          <?php endif; ?>
          <div class="bg-gray-50 rounded-xl p-3">
            <p class="text-[10px] text-gray-400 font-semibold uppercase tracking-wider mb-1">Tanggal Daftar</p>
            <p class="text-sm text-gray-700"><?php echo e($pendaftar->created_at->format('d M Y, H:i')); ?></p>
          </div>
        </div>
      </div>
    </div>

    
    <?php if($pendaftar->lomba?->tipe === 'team' && $pendaftar->anggotaTim->count() > 0): ?>
    <div class="bg-white border border-gray-100 rounded-2xl shadow-sm p-5">
      <h3 class="font-bold text-gray-900 mb-4 flex items-center gap-2 text-sm">
        <div class="w-6 h-6 bg-violet-100 rounded-lg flex items-center justify-center">
          <svg class="w-3.5 h-3.5 text-violet-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z"/>
          </svg>
        </div>
        Anggota Tim — <?php echo e($pendaftar->nama_tim); ?>

      </h3>

      
      <div class="flex items-center gap-3 p-3 bg-violet-50 border border-violet-200 rounded-xl mb-2">
        <div class="w-8 h-8 bg-violet-200 rounded-lg flex items-center justify-center text-violet-700 text-xs font-bold shrink-0">K</div>
        <div class="flex-1 min-w-0">
          <p class="text-sm font-bold text-gray-900"><?php echo e($pendaftar->nama); ?></p>
          <p class="text-xs text-gray-500 font-mono"><?php echo e($pendaftar->nisn); ?></p>
        </div>
        <span class="text-[10px] bg-violet-200 text-violet-700 px-2 py-0.5 rounded-full font-semibold shrink-0">Kapten</span>
      </div>

      
      <?php $__currentLoopData = $pendaftar->anggotaTim; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="flex items-center gap-3 p-3 bg-gray-50 border border-gray-100 rounded-xl mb-2">
        <div class="w-8 h-8 bg-gray-200 rounded-lg flex items-center justify-center text-gray-600 text-xs font-bold shrink-0">
          <?php echo e($a->urutan); ?>

        </div>
        <div class="flex-1 min-w-0">
          <p class="text-sm font-semibold text-gray-900"><?php echo e($a->nama); ?></p>
          <div class="flex items-center gap-2 text-xs text-gray-400">
            <?php if($a->nisn): ?><span class="font-mono"><?php echo e($a->nisn); ?></span><?php endif; ?>
            <?php if($a->kelas): ?><span><?php echo e($a->kelas); ?></span><?php endif; ?>
          </div>
        </div>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php endif; ?>

    
    <div class="bg-white border border-gray-100 rounded-2xl shadow-sm p-5">
      <h3 class="font-bold text-gray-900 mb-4 text-sm">Dokumen Upload</h3>
      <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <?php $__currentLoopData = [['kartu_siswa',$pendaftar->file_kartu_siswa,'Kartu Siswa','blue'],['bukti_pembayaran',$pendaftar->file_bukti_pembayaran,'Bukti Pembayaran','emerald']]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$folder,$file,$label,$c]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="border border-gray-100 rounded-xl p-4">
          <p class="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-3"><?php echo e($label); ?></p>
          <?php if(str_starts_with($file,'dummy_')): ?>
            <div class="bg-gray-50 border-2 border-dashed border-gray-200 rounded-xl p-5 text-center text-xs text-gray-400">Data Demo</div>
          <?php else: ?>
            <a href="<?php echo e(route('admin.uploads.serve',['folder'=>$folder,'filename'=>$file])); ?>" target="_blank"
               class="flex items-center gap-3 bg-<?php echo e($c); ?>-50 hover:bg-<?php echo e($c); ?>-100 border border-<?php echo e($c); ?>-200 rounded-xl p-3 transition-all group">
              <div class="w-9 h-9 bg-<?php echo e($c); ?>-100 rounded-lg flex items-center justify-center shrink-0">
                <svg class="w-5 h-5 text-<?php echo e($c); ?>-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
                </svg>
              </div>
              <div class="min-w-0">
                <p class="text-sm font-semibold text-<?php echo e($c); ?>-700">Lihat File</p>
                <p class="text-xs text-<?php echo e($c); ?>-400 truncate"><?php echo e($file); ?></p>
              </div>
            </a>
          <?php endif; ?>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>
  </div>

  
  <div class="space-y-5">
    <div class="bg-white border border-gray-100 rounded-2xl shadow-sm p-5">
      <h3 class="font-bold text-gray-900 mb-4 text-sm">Ubah Status</h3>
      <form method="POST" action="<?php echo e(route('admin.pendaftar.verifikasi',$pendaftar)); ?>">
        <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
        <div class="space-y-2 mb-4">
          <?php $__currentLoopData = [['Belum','amber','⏳ Belum'],['Terverifikasi','emerald','✅ Terverifikasi'],['Ditolak','red','❌ Ditolak']]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$val,$color,$label]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <label class="flex items-center gap-3 p-3 rounded-xl border-2 cursor-pointer transition-all
                        <?php echo e($pendaftar->status_verifikasi===$val?'border-'.$color.'-400 bg-'.$color.'-50':'border-gray-100 hover:border-gray-200 hover:bg-gray-50'); ?>">
            <input type="radio" name="status" value="<?php echo e($val); ?>" <?php echo e($pendaftar->status_verifikasi===$val?'checked':''); ?> class="accent-blue-600">
            <span class="text-sm font-medium text-gray-700"><?php echo e($label); ?></span>
          </label>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <button type="submit"
                class="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2.5 rounded-xl text-sm transition-all active:scale-95">
          Simpan Status
        </button>
      </form>
    </div>

    <div class="bg-red-50 border border-red-100 rounded-2xl p-5">
      <h3 class="font-bold text-red-700 mb-1 text-sm">Hapus Data</h3>
      <p class="text-xs text-red-400 mb-4">Tindakan ini tidak bisa dibatalkan.</p>
      <form method="POST" action="<?php echo e(route('admin.pendaftar.destroy',$pendaftar)); ?>"
            data-confirm='Yakin hapus data <?php echo e(addslashes($pendaftar->nama)); ?>?'>
        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
        <button class="w-full bg-red-600 hover:bg-red-700 text-white font-semibold py-2.5 rounded-xl text-sm transition-all active:scale-95">
          🗑️ Hapus Pendaftar
        </button>
      </form>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\milbos\resources\views/admin/pendaftar/show.blade.php ENDPATH**/ ?>